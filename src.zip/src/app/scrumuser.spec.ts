import { Scrumuser } from './scrumuser';

describe('Scrumuser', () => {
  it('should create an instance', () => {
    expect(new Scrumuser()).toBeTruthy();
  });
});
